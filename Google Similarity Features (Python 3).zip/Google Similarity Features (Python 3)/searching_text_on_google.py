#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from bs4 import BeautifulSoup,NavigableString,Tag
import sys
import numpy as np
from selenium.webdriver.common.keys import Keys
import requests
import selenium as sel
import re
import pandas as pd
from selenium import webdriver
import time
from selenium.webdriver.common.keys import Keys

options = webdriver.ChromeOptions()

####### Please change the path to google chrome and the chrome driver here
options.binary_location = "C:\Program Files (x86)\Google\Chrome\Application\chrome.exe"
chrome_driver_binary = r"C:\Users\Rabeaa\AppData\Roaming\Python\chromedriver.exe"
import os

url="https://www.google.com"
import datetime
from time import gmtime, strftime

#the function below matches the sentences
from nltk.stem.isri import ISRIStemmer
from nltk import word_tokenize
stemmer = ISRIStemmer()
def match_sentences(sent1,sent2):
    set1=[]
    set2=[]
    for j in word_tokenize(sent1):
        set1.append(stemmer.stem(j))
    for j in word_tokenize(sent2):
        set2.append(stemmer.stem(j))
    ratio = len(set(set1).intersection(set2)) / float(len(set(set1).union(set2)))
    return(ratio)

## The function below searches for the tweet and gives the details for first page

def search(tweet):
    time.sleep(30)
    try:
        
        driver = webdriver.Chrome(chrome_driver_binary, chrome_options=options)
        driver.get(url)
        time.sleep(10)
        #data['text'][0]
        search_word=tweet
        fill_search=driver.find_element_by_name('q')
        time.sleep(5)
        fill_search.send_keys(search_word)
        time.sleep(5)
        fill_search.send_keys(Keys.RETURN)
        #headings=fill_search.find_elements_by_xpath("//div[@class='rc']/h3[@class='r']")
        #details=fill_search.find_elements_by_xpath("//div[@class='s']/div/span")
        time.sleep(15)
        headings=driver.find_elements_by_xpath("//div[@class='rc']/h3[@class='r']")
        details=driver.find_elements_by_xpath("//div[@class='s']/div/span")
        text=[]
        head=[]
        marker=re.compile(r'[0-9]+ -')
        for i in range(len(details)):
            head.append(headings[i].text)
            t=re.split(marker,details[i].text)
            if len(t)>1:
                text.append(t[1])
            else:
                text.append(t[0])
        dataframe=pd.DataFrame()
        dataframe['headings']=head
        dataframe['text']=text
        dataframe['blank']=""
        dataframe['joined_text']=dataframe['headings']+dataframe['blank']+dataframe['text']
        dataframe['score']=dataframe['joined_text'].apply(lambda x: match_sentences(x,tweet))
        dataframe['average_score']=np.mean(dataframe['score'].values)
        ret=dataframe.loc[dataframe['score'].idxmax()]
        #time.sleep(30) ##### please change this to 60 seconds
        print((tweet,ret))
        #print(ret)
        #driver.close()
        #return(pd.DataFrame(ret))
    except Exception as e:
        print(e)
        dataframe=pd.DataFrame()
        dataframe['headings']=["error occurred"]
        dataframe['text']=["error occurred"]
        dataframe['blank']=["error occurred"]
        dataframe['joined_text']=["error occurred"]
        dataframe['score']=[0]
        dataframe['average_score']=[0]
        ret=dataframe.loc[dataframe['score'].idxmax()]
    try:
        driver.close()
    except:
        pass
    ret=pd.DataFrame(ret)
    ret.drop("blank",inplace=True,axis=0)
    ret.drop("joined_text",inplace=True,axis=0)
    ret=ret.transpose()
    ret=ret.reset_index(drop=True)
    return((ret.loc[0,'headings'],ret.loc[0,'text'],ret.loc[0,'score'],ret.loc[0,'average_score']))   
        
######## reading from json file into a dataframe
data=pd.read_json("new_tweets.json",encoding="utf-8-sig")
# enter path of data containing annotations
annotations=pd.read_json("annotations.json",encoding="utf-8-sig")
data=pd.merge(data,annotations,on="tweetid")
data['tweetid']=data['tweetid'].apply(lambda x:str(x))
data=data.dropna(subset=['text'])

######### taking out only the tweet text from the data
texts=data['text']


from googletrans import Translator
translator=Translator()

# defining a function for translating entire word to English
def translate_word(word):
    try:
        w=translator.translate(word)
        text=w.text
    except Exception as e:
        print(e)
        text=word
    return(text)

# defining a function for translating each letter to English
def translate_letter(word):
    try:
        text=""
        for j in word:
            w=translator.translate(j)
            text=text+w.text
    except Exception as e:
        print(e)
        text=word
    return(text)

## comparison of word for similarity
from fuzzywuzzy import fuzz
def comp_word(w):
    score=fuzz.ratio(translate_word(w[0]),translate_word(w[1]))
    #print(score)
    return(score)

## comparison of word by for similarity using letter translation
#from fuzzywuzzy import fuzz
def comp_letter(w):
    score=fuzz.ratio(translate_letter(w[0]),translate_letter(w[1]))
    #print(score)
    return(score)
###### searching all the tweets in a loop. Please break the kernel if you don't want the execution to continue anymore
ntweets=1
i=0
while i*ntweets<=len(data):
    data234=data[(ntweets*i):(ntweets*(i+1))]
    data234=data234.reset_index(drop=True)
    #data234['output_after_tweet_comp']=data234['text'].apply(search)
    heads=[]
    te=[]
    sc=[]
    avg_sc=[]
    for k in range(len(data234)):
        res=search(data234.loc[k,'text'].split("http")[0].strip()) # changes made
        heads.append(res[0].encode("utf-8"))
        te.append(res[1].encode("utf-8"))
        sc.append(res[2])
        avg_sc.append(res[3])
    data234['headings']=heads
    data234['searched_text']=te
    data234['score']=sc
    data234['average_score']=avg_sc
    #data234[['headings','text','score','average_score']]=data234['text'].apply(search)

    #comparison of screen name and name

    # creating dataframe containing only the name and the screenname
    df1=data234[['name','screenname']]
    df1.head()
    df1['word_comp_score']=df1.apply(comp_word,axis=1)
    df1['letter_comp_score']=df1.apply(comp_letter,axis=1)

    df1['max_score']=df1[['word_comp_score','letter_comp_score']].apply(lambda x:max(int(x[0]),int(x[1])),axis=1)
    df1.drop("word_comp_score",inplace=True,axis=1)
    df1.drop("letter_comp_score",inplace=True,axis=1)
    data234['name_comparison_score']=df1['max_score']

    ##### please change the path below to save the result
    #data12=data234[['tweetid','name_comparison_score','output_after_tweet_comp']]
    #data12=data234[['tweetid','name_comparison_score','headings','searched_text','score','average_score']]
    data12=data234[['tweetid','name_comparison_score','score','average_score','iscredible']]
    data12['tweetid']=data12['tweetid'].apply(lambda x: "{}".format(x))
    path="tweets_results.json".format(i)
    data12.to_json(path,force_ascii=False,orient="records")
    i=i+1

data234=data[(ntweets*i):]
data234=data234.reset_index(drop=True)
#data234['output_after_tweet_comp']=data234['text'].apply(search)
heads=[]
te=[]
sc=[]
avg_sc=[]
for k in range(len(data234)):
    res=search(data234.loc[k,'text'])
    heads.append(res[0])
    te.append(res[1])
    sc.append(res[2])
    avg_sc.append(res[3])
data234['headings']=heads
data234['searched_text']=te
data234['score']=sc
data234['average_score']=avg_sc
#data234[['headings','text','score','average_score']]=data234['text'].apply(search)

#comparison of screen name and name

# creating dataframe containing only the name and the screenname
df1=data234[['name','screenname']]
df1.head()
df1['word_comp_score']=df1.apply(comp_word,axis=1)
df1['letter_comp_score']=df1.apply(comp_letter,axis=1)

df1['max_score']=df1[['word_comp_score','letter_comp_score']].apply(lambda x:max(int(x[0]),int(x[1])),axis=1)
df1.drop("word_comp_score",inplace=True,axis=1)
df1.drop("letter_comp_score",inplace=True,axis=1)
data234['name_comparison_score']=df1['max_score']

##### please change the path below to save the result
#data12=data234[['tweetid','name_comparison_score','output_after_tweet_comp']]
#data12=data234[['tweetid','name_comparison_score','headings','searched_text','score','average_score']]
data12=data234[['tweetid','name_comparison_score','score','average_score','iscredible']]
path="tweets_results.json".format(i)
data12.to_json(path,force_ascii=False,orient="records")
    

